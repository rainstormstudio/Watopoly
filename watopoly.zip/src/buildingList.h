#include "./buildings/academicBuilding.h"
#include "./buildings/gym.h"
#include "./buildings/residence.h"
